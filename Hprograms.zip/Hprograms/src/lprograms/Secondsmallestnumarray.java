package lprograms;
public class Secondsmallestnumarray {
	public static void main(String[] args) {
		int arr[]= {18,17,45,1,33,7,99,9,8};
		int smallest=arr[0];
		int secondsmallest=arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i]<smallest) {
				secondsmallest=smallest;
				smallest=arr[i];
			}
			else if(arr[i]<secondsmallest&&arr[i]!=smallest) {
				secondsmallest=arr[i];
			}
		}
		System.out.println("The second smallest number in the array is: "+secondsmallest);
	}
}