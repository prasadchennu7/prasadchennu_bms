package lprograms;

public class Arrreverse {
	public static void main(String[] args) {
	int arr[]= {7,18,17,45,33,99,9,8};
	for(int i=arr.length-1;i>=0;i--) {
		System.out.println(arr[i]);
	}
}
}