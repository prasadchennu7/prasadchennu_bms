package com;

public class Cnumvowel {
	public static void main(String[] args) {
	String s="Sumanth";
	int count=0;
	 
	}
}
