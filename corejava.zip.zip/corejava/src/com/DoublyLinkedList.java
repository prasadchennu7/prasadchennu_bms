package com;
class Node1{
	int data;
	Node1 next;
	Node1 prev;
	Node1(int val){
		data=val;
		next=null;
		prev=null;
	}
}
public class DoublyLinkedList {
	static void forwardtraversal(Node1 head) {
		Node1 curr=head;
		while(curr!=null) {
			System.out.println(curr.data+"");
			curr=curr.next;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		Node1 head=new Node1(31);
		Node1 second=new Node1(25);
		Node1 third=new Node1(10);
		head.next=second;
		second.prev=head;
		second.next=third;
		third.prev=second;
		System.out.println("Forward traversal:");
		forwardtraversal(head);
	}
}
