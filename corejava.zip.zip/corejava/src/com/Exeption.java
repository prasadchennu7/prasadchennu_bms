package com;

public class Exeption {
	public static void main(String[] args) {
		int a=100;
		int b=0;
		int c=a+b;
		int d=a-b;
		System.out.println(c);
		System.out.println(d);
		try {
			int res=a/b;
			System.out.println(res);
		}
		catch(Exception e) {
			System.out.println("Its simply not possible");
		}
		int f=a*10;
		System.out.println(f);
	}
}
