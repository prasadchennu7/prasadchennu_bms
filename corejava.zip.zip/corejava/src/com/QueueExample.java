package com;
import java.util.LinkedList;
import java.util.Queue;
public class QueueExample {
	public static void main(String[] args) {
		Queue<Integer>queue=new LinkedList<>();
		queue.add(8);
		queue.add(33);
		queue.add(45);
		System.out.println("Queue:"+queue);
		System.out.println("Front element:"+queue.peek());
		System.out.println("Removed:"+queue.remove());
		System.out.println("Queue after remove:"+queue);
		System.out.println("Polled:"+queue.poll());
		System.out.println("Queue after poll:"+queue);
		System.out.println("Size:"+queue.size());
		System.out.println("IsEmpty?"+queue.isEmpty());
	}
}
