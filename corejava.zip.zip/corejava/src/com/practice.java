import javax.swing.*; // Import Swing components like JFrame and JPanel
import java.awt.*;    // Import AWT classes like Graphics and Color

public class SimpleGraphicsDemo extends JPanel { // Extend JPanel for drawing

    /**
     * This method is automatically called when the JPanel needs to be drawn.
     * You override it to define what gets drawn on the panel.
     * @param g The Graphics object used for drawing.
     */
    @Override
    protected void paintComponent(Graphics g) {
        // Always call super.paintComponent(g) first.
        // This ensures the background is cleared and other painting happens correctly.
        super.paintComponent(g); 

        // Set the drawing color to red.
        g.setColor(Color.RED); 
        // Draw a filled rectangle. (x, y, width, height)
        g.fillRect(50, 50, 100, 75); 

        // Set the drawing color to blue.
        g.setColor(Color.BLUE);
        // Draw a line. (x1, y1, x2, y2)
        g.drawLine(20, 20, 180, 180);

        // Set the drawing color to green.
        g.setColor(Color.GREEN);
        // Draw an oval (to draw a circle, make width and height equal). (x, y, width, height)
        g.drawOval(100, 150, 60, 60);

        // Set the drawing color to orange.
        g.setColor(Color.ORANGE); 
        // Draw a string (text). (string, x, y)
        g.drawString("Hello, Java Graphics!", 20, 220); 

        // Set the font.
        g.setFont(new Font("Arial", Font.BOLD, 18));
        // Draw another string with the new font.
        g.drawString("Styled Text", 20, 250); 
    }

    public static void main(String[] args) {
        // Create a JFrame (the main window).
        JFrame frame = new JFrame("Simple Graphics Demo"); 

        // Set the size of the window.
        frame.setSize(400, 300);

        // Set the default close operation (exit the application when the window is closed).
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 

        // Create an instance of our custom JPanel.
        SimpleGraphicsDemo panel = new SimpleGraphicsDemo();

        // Add the custom JPanel to the JFrame's content pane.
        frame.add(panel);

        // Make the window visible.
        frame.setVisible(true);
    }
}
