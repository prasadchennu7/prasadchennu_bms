package com;
class Node2{
	int data;
	Node2 next;
	Node2 prev;
	Node2(int val){
		data=val;
		next=null;
		prev=null;
	}
}
public class DoublyLinkedListback {
	public static void backwardtraversal(Node2 tail) {
		Node2 curr=tail;
		while(curr!=null) {
			System.out.println(curr.data+"");
			curr=curr.prev;
		}
	}
	public static void main(String[] args) {
		Node2 head=new Node2(7);
		Node2 second=new Node2(8);
		Node2 third=new Node2(9);
		head.next=second;
		second.prev=head;
		third.prev=second;
		System.out.println("Backward traversal:");
		backwardtraversal(third);
	}
}