package com;
import java.util.Scanner;
public class neif {
public static void main(String[]arg) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number");
	int n=sc.nextInt();
	if(n%3==0) {
		if(n%9==0) {
			System.out.println("Number is divisible by 3 & 9");
		}
	}
	else {
		System.out.println("Number is not divisible by 3 & 9");
	}
}
}
