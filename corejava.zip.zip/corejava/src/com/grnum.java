package com;
import java.util.Scanner;
public class grnum {
	public static void main(String[]arg) {
		Scanner sc=new Scanner(System.in);
		System.out.print("a:");
		int a=sc.nextInt();
		System.out.print("b:");
		int b=sc.nextInt();
		System.out.print("c:");
		int c=sc.nextInt();
		if(a>b&&a>c) {
			System.out.println(a+" is greatest number");
		}
			else if(b>a&&b>c) {
				System.out.println(b+" is greatest number");
		}
		else {
			System.out.println(c+" is greatest number");
		}
	}
}
