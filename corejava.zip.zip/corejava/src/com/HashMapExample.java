package com;
import java.util.HashMap;
public class HashMapExample {
	public static void main(String[] args) {
		HashMap<Integer,String>map=new HashMap();
		map.put(1,"coolie");
		map.put(2, "HHVM");
		map.put(3, "War2");
		map.put(2, "LCU");
		System.out.println(map.get(1));
		System.out.println(map.get(2));
		System.out.println(map.containsKey(3));
		System.out.println(map.containsValue("coolie"));
		map.remove(3);
		for(Integer key:map.keySet()) {
			System.out.println(key+"-->"+map.get(key));
		}
	}
}