package com;

public class forl {
public static void main(String[]arg) {
	int start=1;
	int end=100;
	while(start<=end) {
		System.out.println(start);
		start++;
	}
}
}
