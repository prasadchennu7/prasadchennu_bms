package com;

public class methodoverriding {
public void whatsappversions() {
	System.out.println("Version 1----> only single ticks");
}
}
