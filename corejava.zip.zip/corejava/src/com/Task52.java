package com;

public class Task52 implements Task51 {
@Override
public void Task5() {
	// TODO Auto-generated method stub
	System.out.println("Taskk5");
}

@Override
public void Task51() {
	// TODO Auto-generated method stub
	System.out.println("Completed");
}
public static void main(String[] args) {
	Task52 T52=new Task52();
	T52.Task5();
	T52.Task51();
}
}
