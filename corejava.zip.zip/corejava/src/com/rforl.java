package com;
import java.util.Scanner;
public class rforl {
public static void main(String[]arg) {
	Scanner sc=new Scanner(System.in);
	int sum=0;
	int a;
	for(a=1;a<=10;a++)
	{
		sum=sum+a;
	}
	System.out.println(sum);
}
}
