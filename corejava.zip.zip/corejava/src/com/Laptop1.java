package com;

public class Laptop1 {
	public static void main(String[] args) {
		System.out.println("Laptop details");
	Laptop l=new Laptop();
	l.setName("Asus");
	l.setModel("TUF15");
	l.setRamMemory("5GB");
	l.setRomMemory("512GB");
	l.setCost(80000);
	l.display();
	System.out.println("-----------------");
	l.setName("Samsung Galaxy");
	l.setModel("Book5");
	l.setRamMemory("8GB");
	l.setRomMemory("1TB");
	l.setCost(90000);
	l.display();
	System.out.println("-----------------");
	System.out.println("-----------------");
}
	
}
