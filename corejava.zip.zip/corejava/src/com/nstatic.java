package com;

public class nstatic {
	int age=29;
	float weight=29;
	String height="2'9";
	String hair="fall";
	public void data() {
		System.out.println("Person Data");
		System.out.println("------------");
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
		System.out.println("Hair: "+hair);
		System.out.println("Height: "+height);
	}
	public static void main(String[] args) {
		nstatic ns=new nstatic();
		ns.data();
	}
}
