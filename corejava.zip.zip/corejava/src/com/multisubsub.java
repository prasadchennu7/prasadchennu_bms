package com;

public class multisubsub extends multisub{
public void car2() {
	System.out.println("BMW M5");
}
public static void main(String[] args) {
	multisubsub mss=new multisubsub();
	mss.car();
	mss.car1();
	mss.car2();
}
}
