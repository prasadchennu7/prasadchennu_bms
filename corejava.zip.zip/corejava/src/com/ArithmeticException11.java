package com;

public class ArithmeticException11 {
	public static void main(String[] args) {
		int x=17;
		int y=0;
		try {
			System.out.println(x/y);
		}
		catch(ArithmeticException e) {
			System.out.println("Not possible ra velimudhra");
		}
	}
}
