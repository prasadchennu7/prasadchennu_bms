package com;

public class Arrayy7 {
	public static void main(String[] args) {
		int arr[]= {7,18,45,33,10,8,17};
		int smallest =arr[0];
        for (int i = 0; i < arr.length; i++) { 
            if (arr[i] < smallest) { 
                smallest = arr[i]; 
            }
        }
        System.out.println("The smallest number in the array is: " + smallest);
    }
}