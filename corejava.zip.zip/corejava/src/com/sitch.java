package com;
import java.util.Scanner;
public class sitch {
public static void main(String[]arg) {
	Scanner sc=new Scanner(System.in);
	char ch=sc.next().charAt(0);
	switch(ch) {
	case 'a':
	{
		System.out.println("vowel");
	}
	case 'A':
	{
		System.out.println("vowel");
	}
	case 'e':
	{
		System.out.println("vowel");
}
	case 'E':
	{
		System.out.println("vowel");
}
	case 'i':
	{
		System.out.println("vowel");
	}
	case 'I':
	{
		System.out.println("vowel");
	}
	case 'o':
	{
		System.out.println("vowel");
	}
	case 'O':
	{
		System.out.println("vowel");
	}
	case 'u':
	{
		System.out.println("vowel");
	}
	case 'U':
	{
		System.out.println("vowel");
	}
}
}
}