package com;

public abstract class mabstract {
abstract public void run();
}
