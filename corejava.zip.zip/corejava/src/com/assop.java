package com;

public class assop {
	public static void main(String[]arg) {
		int a=4;
		a +=5;
		System.out.println(a);
	}
}
