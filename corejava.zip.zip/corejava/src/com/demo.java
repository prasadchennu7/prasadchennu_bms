package com;

public class demo {
public static void main(String[]arg) {
	String s=("surya bhai");
	String a=s;
	System.out.println(a);
	long l=34l;
}
}
