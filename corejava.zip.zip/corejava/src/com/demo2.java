package com;

public class demo2 {
public static void main(String[]arg) {
	float f=10.01f;
	short s=(short)f;
	System.out.println(s);
}
}
