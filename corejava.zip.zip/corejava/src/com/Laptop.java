package com;

public class Laptop {
	private String Name;
	private String Model;
	private String RamMemory;
	private String RomMemory;
	private int Cost;
	public Laptop() {
	}
	public Laptop(String Name,String Model,String RamMemory,String RomMemory,int cost) {
	this.Name=Name;
	this.Model=Model;
	this.RamMemory=RamMemory;
	this.RomMemory=RomMemory;
	this.Cost=Cost;
}
	public void setName(String Name) {
		this.Name=Name;
	}
	public String GetName() {
		return Name;
	}
	public void setModel(String Model) {
		this.Model=Model;
	}
	public String GetModel() {
		return Model;
	}
	public void setRamMemory(String RamMemory) {
		this.RamMemory=RamMemory;
	}
	public String GetRamMemory() {
		return RamMemory;
	}
	public void setRomMemory(String RomMemory) {
		this.RomMemory=RomMemory;
	}
	public String GetRomMemory() {
		return RomMemory;
	}
	public void setCost(int Cost) {
		this.Cost=Cost;
	}
	public int GetCost() {
		return Cost;
	}
	public void display() {
		System.out.println("Name of the laptop:"+GetName());
		System.out.println("Name of the model:"+GetModel());
		System.out.println("Ram Memory:"+GetRamMemory());
		System.out.println("Rom Memory:"+GetRomMemory());
		System.out.println("Cost of the laptop:"+GetCost());
	}
	
}
