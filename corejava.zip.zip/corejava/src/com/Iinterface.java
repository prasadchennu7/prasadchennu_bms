package com;

public class Iinterface implements sample {
public void sample() {
	System.out.println("Sample block");
}
public static void main(String[] args) {
	Iinterface t=new Iinterface();
	t.sample();
}
}
