package com;

public class Nullpointerexception {
	public static void main(String[] args) {
		String s=null;
		try {
			System.out.println(s.length());
		}
		catch(Exception e) {
			System.out.println("Lopala em ledhu -- Dolla");
		}
	}
}
