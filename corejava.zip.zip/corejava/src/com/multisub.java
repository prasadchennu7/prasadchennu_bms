package com;

public class multisub extends multisuper {
public void car1() {
	System.out.println("BMW M3");
}
public static void main(String[] args) {
	multisub ms=new multisub();
	ms.car1();
	ms.car();
}
}
