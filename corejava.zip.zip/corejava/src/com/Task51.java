package com;

public interface Task51 extends Task5{
void Task51();
}
