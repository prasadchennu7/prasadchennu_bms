package com;
import java.util.Stack;
public class StackExample {
	public static void main(String[] args) {
		Stack<Integer>Stack=new Stack<>();
		Stack.push(7);
		Stack.push(17);
		Stack.push(18);
		System.out.println("Stack:"+Stack);
		System.out.println("Top element:"+Stack.peek());
		System.out.println("Popped:"+Stack.pop());
		System.out.println("Stack after pop:"+Stack);
		System.out.println("Position of 7:"+Stack.search(7));
		System.out.println("Is stack empty?"+Stack.isEmpty());
		System.out.println("Size:"+Stack.size());
	}
}
