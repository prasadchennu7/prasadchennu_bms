package com;

public class Linearsearch {
	public static void main(String[] args) {
		int arr[]= {45,33,17,9,8,7,10,18};
	int target=7;
	boolean found=false;
	for(int i=0;i<=arr.length-1;i++) {
		if(arr[i]==target) {
			System.out.println("found at index:"+i);
			found=true;
			break;
		}
	}
	if(!found) {
		System.out.println("not found");
}
}
}