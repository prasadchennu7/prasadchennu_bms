package com;
class Node{
	int data;
	Node next;
	Node(int new_data){
		this.data=new_data;
		this.next=null;
	}
}
public class SingleLinkedList {
	public static void traverselist(Node head) {
		while(head!=null) {
			System.out.println(head.data+"");
			head=head.next;
		}
		System.out.println();	}
	public static void main(String[] args) {
		Node head=new Node(9);
		head.next=new Node(99);
		head.next.next=new Node(1);
		head.next.next.next=new Node(12);
		traverselist(head);
	}
}
