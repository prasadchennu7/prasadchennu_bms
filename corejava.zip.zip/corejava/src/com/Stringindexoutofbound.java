package com;
import java.io.*;
public class Stringindexoutofbound {
	public static void main(String[] args) {
		String s="HHVM";
		try {
			char ss=s.charAt(3);
			System.out.println(ss);
		}
		catch(Exception e) {
			System.out.println("kanipinchaledu");
		}
	}
}
