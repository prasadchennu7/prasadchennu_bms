package com;

public class prnum {
public static void main(String[]arg) {
	int start=5;
	int end=100;
	int n=5;
	int count=0;
	do {
		if(n%start==0) {
			count++;
		}
		if(count==2) {
			System.out.println("prime");
		}
		else {
			System.out.println("not");
		}
		start++;
	}
	while(start<=end);
}
}
