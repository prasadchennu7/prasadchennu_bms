package com;

public interface Task5 {
void Task5();
}
