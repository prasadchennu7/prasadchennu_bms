package com;

public class singlesuperclass {
int a;
int b;
public void display() {
	System.out.println(a);
	System.out.println(b);
}
public static void main(String[] args) {
	singlesuperclass ss=new singlesubclass();
	ss.a=90;
	ss.b=78;
	ss.display();
}
}
