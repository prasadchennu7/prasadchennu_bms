package com;

public class Spredefined {
	public static void main(String[] args) {
		String s=" My name is mary biscuit";
		System.out.println(s.length());
		char a=s.charAt(1);
		System.out.println(a);
		String s1=s.toUpperCase();
		System.out.println(s1);
		String s2=s.toLowerCase();
		System.out.println(s2);
		String s3=s.trim();
		System.out.println(s3);
		String s4=s.replace('a','e');
		
		System.out.println(s4);
		char[]ch=s.toCharArray();
		System.out.println(ch);
		System.out.println(s.startsWith("M"));
		System.out.println(s.endsWith("t"));
		System.out.println(s.isEmpty());
	}
}
