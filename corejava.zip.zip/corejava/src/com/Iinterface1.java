package com;

public Iinterface1 sample{
void sample();
}
