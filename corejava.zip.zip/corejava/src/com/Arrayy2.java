package com;

public class Arrayy2 {
	public static void main(String[] args) {
		String[]arr=new String[4];
		arr[0]="coolie";
		arr[1]="war2";
		arr[2]="HHVM";
		arr[3]="Kingdom";
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]);
		}
}
}