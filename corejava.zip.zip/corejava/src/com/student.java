package com;

public class student {
	String uniform="blue";
	int idcard=123;
	String dept="ECE";
	String section="D";
	String clg="AITS";
public void study() {
	System.out.println("Students details");
	System.out.println("----------------");
	System.out.println("uniform: "+uniform);
	System.out.println("idcard: "+idcard);
	System.out.println("dept: "+dept);
	System.out.println("section: "+section);
	System.out.println("clg: "+clg);
}
public static void main(String[] args) {
	student s=new student();
	s.study();
}
}
