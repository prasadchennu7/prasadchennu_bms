package com;

public class Arrayy {
	public static void main(String[] args) {
		int[]arr=new int[10];
		arr[0]=1;
		arr[1]=2;
		arr[7]=5;
		arr[4]=54;
		System.out.println(arr[7]);
		System.out.println("------------------");
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[i]);
		}
	}
}
