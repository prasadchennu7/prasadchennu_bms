package com;

public class Arrayy1 {
	public static void main(String[] args) {
	String[]arr=new String[7];
	arr[0]="coolie";
	arr[2]="war2";
	arr[4]="HHVM";
	arr[6]="Kingdom";
	for(int i=0;i<=arr.length-1;i++) {
		System.out.println(arr[i]);
	}
}
}