package com;
import java.io.*;
public class Fhandling {
	public static void main(String[] args) {
		File f=new File("coolie.txt");
			try {
				boolean res=f.createNewFile();
				System.out.println(res);
				System.out.println(f.getAbsolutePath());
		}
			catch(Exception e) {
				System.out.println("Its not true");
			}
	try {
		FileWriter fw=new FileWriter(f);
		fw.write("War2");
		fw.flush();
		fw.close();
	}
	catch(Exception e) {
		System.out.println("cannot write");
	}
	try {
		FileReader fr=new FileReader(f);
		for(int i=0;i<=f.length()-1;i++) {
			System.out.println((char) fr.read());
		}
	}
	catch(Exception e) {
		System.out.println("can't read");
	}
}
}