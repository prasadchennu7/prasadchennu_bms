package com;

public abstract class morabstract extends mabstract{
	@Override
public void run() {
	System.out.println("Running");
}
}
